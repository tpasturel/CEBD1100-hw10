from .CEBD1100homework8ThibaultPasturel import *
